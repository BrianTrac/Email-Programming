from customtkinter import *
from tkinter import *
from PIL import Image
import os

class Frame3(CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.master = master

    def update_frame3(self, message):
        pass

