from tkinter import *
from customtkinter import *
from Frame1 import Frame1
from Frame2 import Frame2

class CustomPanedWindow:
    def __init__(self, master):
        self.master = master
        self.master.iconbitmap("logo.ico")
        self.master.title("Email APP")

         # Create bar frame
        self.frame0 = CTkFrame(self.master, width=900, height=50, bg_color="black", fg_color="SlateGray2")
        self.frame0.pack(expand=True, fill=BOTH)

        # Create a horizontal PanedWindow
        self.paned_window = PanedWindow(self.master, orient= HORIZONTAL, sashrelief=RAISED, sashwidth=3)
       
        
        # Create frames (panes)
        self.frame1 = CTkFrame(self.paned_window, width=200, height=600, bg_color="black", fg_color="SlateGray1")
        self.frame2 = Frame2(self.paned_window, width=300, height=600, bg_color="black", fg_color="SlateGray2")        
        self.frame3 = CTkFrame(self.paned_window, width=400, height=600, bg_color="black", fg_color="SlateGray1")

        # Add widgets to Frame
        Frame1(self.frame1, callback=self.update_frame2)

        # Add frames to the PanedWindow
        self.paned_window.add(self.frame1, minsize=150)
        self.paned_window.add(self.frame2, minsize=200)
        self.paned_window.add(self.frame3, minsize=300)

        # Pack the PanedWindow
        self.paned_window.pack(expand=True, fill=BOTH)


    def update_frame2(self, message):
        self.frame2.update_frame2(message) 
    


if __name__ == "__main__":
    root = CTk()
    app = CustomPanedWindow(root)
    root.mainloop()
