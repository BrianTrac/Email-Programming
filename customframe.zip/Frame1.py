from customtkinter import *
from tkinter import *
from PIL import Image

class Frame1():
    def __init__(self, master, callback):
        super().__init__()
        self.master = master
        self.callback = callback

        # Load Image
        new_message_image = CTkImage(dark_image=Image.open("new_message.png"), size=(20,20))
        send_image = CTkImage(dark_image=Image.open("sent.png"), size=(20,20))
        inbox_image = CTkImage(dark_image=Image.open("inbox.png"), size=(20,20))
        trash_image = CTkImage(dark_image=Image.open("trash.png"), size=(20,20))
        spam_image = CTkImage(dark_image=Image.open("spam.png"), size=(20,20))
    #   folder_image = CTkImage(dark_image=Image.open("inbox.png"), size=(20,20))

        # Create Button 
        self.new_message_button = CTkButton(self.master, height = 20, text="New Message", image=new_message_image, compound=LEFT, font=("Helvetica", 20), fg_color="RoyalBlue" , command=self.new_message_email)
        self.new_message_button.pack(side=TOP, padx=30, pady=30)

        self.send_button = CTkButton(self.master, height = 20, text="Sent", image=send_image, compound=LEFT, font=("Helvetica", 20), fg_color="SlateGray3" , command=self.send_email, anchor="w")
        self.send_button.pack(fill=X, pady=20, padx = 1)
   
        self.inbox_button = CTkButton(self.master, height = 20, text="Inbox", image=inbox_image, compound=LEFT, font=("Helvetica", 20), fg_color="SlateGray3" , command=self.inbox_email, anchor="w")
        self.inbox_button.pack(fill=X, pady=20, padx=1)

        self.trash_button = CTkButton(self.master, height = 20, text="Trash", image=trash_image, compound=LEFT, font=("Helvetica", 20), fg_color="SlateGray3" , command=self.trash_email, anchor="w")
        self.trash_button.pack(fill=X, pady=20, padx=1)

        self.spam_button = CTkButton(self.master, height = 20, text="Spam", image=spam_image, compound=LEFT, font=("Helvetica", 20), fg_color="SlateGray3" , command=self.spam_email, anchor="w")
        self.spam_button.pack(fill=X, pady=20, padx=1)

        # Create ScrollBar
        
    def new_message_email(self):
        print("New Message")
        self.callback("New Message")

    def send_email(self):
        print("Sent")
        self.callback("Sent")   

    def inbox_email(self):
        print("Inbox")
        self.callback("Inbox")

    def trash_email(self):
        print("Trash")
        self.callback("Trash")

    def spam_email(self):
        print("Spam")
        self.callback("Spam")