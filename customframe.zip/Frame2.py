from customtkinter import *
from tkinter import *
from PIL import Image
import os

class Frame2(CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.master = master
        self.selected_button = None
        self.search_bar = CTkEntry(self, width=100, height=15, placeholder_text="Search", fg_color="white", text_color="dark")
        self.search_bar.pack(fill=X, pady=10)    
    #    self.callback = callback

    def update_frame2(self, message):     
        if message != self.selected_button:
            path = "D:/Python/Socket Programming/Email"
            path = os.path.join(path, message)
            folder_list = sorted([folder for folder in os.listdir(path) if os.path.isdir(os.path.join(path, folder))], key=int)
            human_image = CTkImage(dark_image=Image.open("human.png"), size=(20,20))
            self.selected_button = message
            self.destroy_elements()

            for folder in folder_list:
                folder_name = os.path.basename(folder)
                print(folder_name)
                self.button = CTkButton(self, height = 20, text=folder_name, image=human_image, compound=LEFT, font=("Helvetica", 20), fg_color="SlateGray3", border_spacing=1 , command=lambda e=folder_name: self.content_email(e), anchor="w")
                self.button.pack(fill=X, padx = 1)
            
    
    def content_email(self, folder_name):
        print(f"Content email {folder_name}")
    #    self.callback(folder_name)

    def destroy_elements(self):
        # Destroy all elements within the frame
        for widget in self.winfo_children():
            if isinstance(widget, CTkButton):
                widget.destroy()