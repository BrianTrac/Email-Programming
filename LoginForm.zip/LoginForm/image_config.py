# images_config.py

login_image_path = "E:\\Computer_Networking\\Socket\\LoginForm\\login.png"
signup_image_path = "E:\\Computer_Networking\\Socket\\LoginForm\\signup.png"
eye_icon_image_path = "E:\\Computer_Networking\\Socket\\LoginForm\\eye_icon.png"
