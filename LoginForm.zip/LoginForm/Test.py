from logging import RootLogger
from tkinter import *
from tkinter import ttk, messagebox

import ast

class LoginApplication:
    def __init__(self, root):
        self.root = root
        self.root.title('Login')
        self.root.geometry('925x500+300+200')
        self.root.configure(bg="#fff")
        self.root.resizable(False, False)
        self.window_exists = BooleanVar()
        self.window_exists.set(False)
        self.user = Entry(self.root)  # Initialize Entry widget for username
        self.code = Entry(self.root, show='*')  # Initialize Entry widget for password
        self.confirm_code = Entry(self.root, show='*')  # Initialize Entry widget for confirm password
        self.create_login_ui()

    def create_login_ui(self):
        img = PhotoImage(file='login.png')
        Label(self.root, image=img, bg='white').place(x=50, y=50)

        frame = Frame(self.root, width=350, height=350, bg="white")
        frame.place(x=480, y=70)

        heading = Label(frame, text='Sign in', fg="#57a1f8", bg="white", font=('Microsoft YaHei UI Light', 23, 'bold'))
        heading.place(x=100, y=5)

        user = Entry(frame, width=25, fg='black', border=0, bg="white", font=('Microsoft YaHei UI Light', 11))
        user.place(x=30, y=80)
        self.handle_entry(user, 'Username')

        code = Entry(frame, width=25, fg='black', border=0, bg='white', font=('Microsoft Yahei UI Light', 11))
        code.place(x=30, y=150)
        self.handle_entry(code, 'Password', show_password=True)
        self.create_eye_button(frame, 322, 157, code)

        Frame(frame, width=295, height=2, bg='black').place(x=25, y=107)
        Frame(frame, width=295, height=2, bg='black').place(x=25, y=177)

        Button(frame, width=39, pady=7, text='Sign in', bg="#57a1f8", fg='white', border=0, command=self.signin).place(
            x=35, y=204)
        label = Label(frame, text="Don't have an account?", fg='black', bg='white',
                      font=('Microsoft YaHei UI Light', 9))
        label.place(x=75, y=270)

        sign_up = Button(frame, width=6, text='Sign up', border=0, bg='white', cursor='hand2', fg='#57a1f8',
                         command=self.signup_command)
        sign_up.place(x=215, y=270)

    def create_eye_button(self, frame, place_x, place_y, password_entry):
        eye_icon = PhotoImage(file='eye_icon.png').subsample(2, 2)
        eye_button = Button(frame, image=eye_icon, bg='white', borderwidth=0)
        eye_button.image = eye_icon  # Store the image reference
        eye_button.place(x=place_x, y=place_y)

        def start_showing_password(event):
            password_entry.config(show='')

        def stop_showing_password(event):
            password_entry.config(show='*')

        eye_button.bind("<ButtonPress-1>", start_showing_password)
        eye_button.bind("<ButtonRelease-1>", stop_showing_password)

    def handle_entry(self, entry, default_text, show_password=False):
        def on_enter(e):
            if entry.get() == default_text:
                entry.delete(0, 'end')
                if show_password:
                    entry.config(show='*')

        def on_leave(e):
            if entry.get() == '':
                entry.insert(0, default_text)
                if show_password:
                    entry.config(show='')

        entry.insert(0, default_text)
        entry.bind('<FocusIn>', on_enter)
        entry.bind('<FocusOut>', on_leave)

    def signin(self):
        username = self.user.get()
        password = self.code.get()

        file = open('datasheet.txt', 'r')
        d = file.read()
        r = ast.literal_eval(d)
        file.close()

        if username in r.keys() and password == r[username]:
            self.root.withdraw()
            self.window_after_sign_in()
        else:
            messagebox.showerror('Invalid', 'Invalid username or password')

    def window_after_sign_in(self):
        screen = Toplevel(self.root)
        screen.title("App")
        screen.geometry('1280x720+110+35')
        screen.config = 'white'

        screen.protocol("WM_DELETE_WINDOW", lambda: self.show_login_window(screen))

    def show_login_window(self, screen):
        screen.destroy()
        self.root.deiconify()

    def signup_command(self):
        window = Toplevel(self.root)
        window.title("SignUp")
        window.geometry('925x500+300+200')
        window.configure(bg='#fff')
        window.resizable(False, False)

        img = PhotoImage(file='signup.png')
        Label(window, image=img, border=0, bg='white').place(x=50, y=90)

        frame = Frame(window, width=350, height=390, bg='#fff')
        frame.place(x=480, y=50)

        heading = Label(frame, text='Sign up', fg='#57a1f8', bg='white', font=('Microsoft Yahei UI Light', 23, 'bold'))
        heading.place(x=100, y=5)

        user = Entry(frame, width=25, fg='black', border=0, bg='white', font=('Microsoft Yahei UI Light', 11))
        user.place(x=30, y=80)
        self.handle_entry(user, 'Username')

        code = Entry(frame, width=25, fg='black', border=0, bg='white', font=('Microsoft Yahei UI Light', 11))
        code.place(x=30, y=150)
        self.handle_entry(code, 'Password', show_password=True)
        self.create_eye_button(frame, 322, 160, code)

        confirm_code = Entry(frame, width=25, fg='black', border=0, bg='white', font=('Microsoft Yahei UI Light', 11))
        confirm_code.place(x=30, y=220)
        self.handle_entry(confirm_code, 'Confirm Password', show_password=True)
        self.create_eye_button(frame, 322, 230, confirm_code)

        Frame(frame, width=295, height=2, bg='black').place(x=25, y=107)
        Frame(frame, width=295, height=2, bg='black').place(x=25, y=177)
        Frame(frame, width=295, height=2, bg='black').place(x=25, y=247)

        Button(frame, width=39, pady=7, text='Sign up', bg='#57a1f8', fg='white', border=0, command=self.signup).place(
            x=35, y=280)
        label = Label(frame, text='I have an account', fg='black', bg='white',
                      font=('Microsoft YaHei UI Light', 9))
        label.place(x=90, y=340)

        sign_in = Button(frame, width=6, text='Sign in', border=0, bg='white', cursor='hand2', fg='#57a1f8',
                         command=self.sign)
        sign_in.place(x=200, y=340)
        if not self.window_exists.get():
            self.window_exists.set(True)

        window.mainloop()

    def signup(self):
        username = self.user.get()
        password = self.code.get()
        confirm_password = self.confirm_code.get()

        if password == confirm_password:
            try:
                file = open('datasheet.txt', 'r+')
                d = file.read()
                r = ast.literal_eval(d)

                dict2 = {username: password}
                r.update(dict2)
                file.seek(0)
                file.truncate()
                file.write(str(r))
                file.close()

                messagebox.showinfo('Signup', 'Successfully sign up')

                self.window.destroy()
                self.root.deiconify()
                self.window_exists.set(False)
            except:
                file = open('datasheet.txt', 'w')
                pp = str({'Username': 'password'})
                file.write(pp)
                file.close()
        else:
            messagebox.showerror('Invalid', "The passwords don't match ")

    def sign(self):
        self.window.destroy()

if __name__ == "__main__":
    root = Tk()
    app = LoginApplication(root)
    root.mainloop()
